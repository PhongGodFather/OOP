#include "SortAlg.h"
SortAlg::SortAlg()
{
    currentAlgorithm = InsertionSort;
}
SortAlg* SortAlg::_algorithm = NULL;
SortAlg* SortAlg::getObject(void(*pAlg)(float[], int)) {
    if (_algorithm == NULL) {
        _algorithm = new SortAlg();
    }
    if (pAlg != NULL) {
        _algorithm->currentAlgorithm = pAlg;
    }
    return _algorithm;
}
void SortAlg::sort(float a[], int n) {
    if (currentAlgorithm != NULL) {
        currentAlgorithm(a, n);
    }
}
void SortAlg::SelectionSort(float a[], int n) {
    int min = 0;
    for (int i = 0; i < n - 1; i++) {
        min = i;
        for (int j = i + 1; j < n; j++) {
            if (a[j] < a[min]) {
                min = j;
            }
        }
        if (min != i) {
            swap(a[min], a[i]);
        }
    }
}
void SortAlg::InterchangeSort(float a[], int n)
{
    for (int i = 0; i < n - 1; i++) {
        for (int j = i + 1; j< n; j++) {
            if (a[j] < a[i]) {
                swap(a[i], a[j]);
            }
        }
    }
}
void SortAlg::InsertionSort(float a[], int n)
{
    int pos;
    float x;
    for (int i = 1; i < n; i++)
    {
        x = a[i];
        for (pos = i; (pos > 0) && (a[pos - 1] > x); pos--)
        {
            a[pos] = a[pos - 1];
        }
        a[pos] = x;
    }
}