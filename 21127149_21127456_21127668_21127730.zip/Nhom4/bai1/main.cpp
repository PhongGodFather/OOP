#include "SortAlg.h"
int main()
{
	float a[] = { 1.4F,-5.2F,3.3F,0,1 };
	int n = sizeof(a) / sizeof(a[0]);
	SortAlg* alg1 = SortAlg::getObject(SortAlg::InterchangeSort);
	alg1->sort(a, n);
	cout << " Mang sau khi sap xep tang dan: " << endl;
	for (int i = 0; i < n; i++)
		cout << a[i] << " ";
	cout << endl;
	
	SortAlg* alg2 = SortAlg::getObject(SortAlg::InsertionSort);
	alg2->sort(a, n);
	cout << " Mang sau khi sap xep tang dan: " << endl;
	for (int i = 0; i < n; i++)
		cout << a[i] << " ";
	cout << endl;
	
	SortAlg* alg3 = SortAlg::getObject(SortAlg::SelectionSort);
	alg3->sort(a, n);
	cout << " Mang sau khi sap xep tang dan: " << endl;
	for (int i = 0; i < n; i++)
		cout << a[i] << " ";
	return 0;
}