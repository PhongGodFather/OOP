#pragma once
#ifndef _SortAlg_
#define _SortAlg_
#include <iostream>
#include <math.h>
using namespace std;
class SortAlg
{
	static SortAlg* _algorithm;
	void (*currentAlgorithm)(float[], int);
	SortAlg();
public:
	static SortAlg* getObject(
		void (*pAlg)(float[], int) = NULL
	);
	static void SelectionSort(float[], int);
	static void InsertionSort(float[], int);
	static void InterchangeSort(float[], int);
	void sort(float[], int);
};

#endif // !_SortAlg_
