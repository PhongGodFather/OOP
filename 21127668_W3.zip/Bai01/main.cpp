#include "NhanVien.h"
int main()
{
	NhanVien a("Dat Thanh", 800);
	cout << a << endl;
	NhanVien b(a);
	b.setName("Hai Dang");
	cout << b << endl;
	for (int i = 0; i < 5; i++)
	{
		NhanVien clone = b;
		clone.setName("De tu thu " + to_string(i) + " cua " + b.getChucDanh() + " " + b.getName());
		cout << clone.getName() << endl;
	}
}