#pragma once
#ifndef NHAN_VIEN
#define NHAN_VIEN
#include <iostream>
#include <string>
using namespace std;
class NhanVien
{
	string HoTen;
	int ngayLamViec;
	float HeSoLuong;
	string ID;
	string ChucDanh;
public:
	NhanVien();
	NhanVien(string name, string ID, string Position, int workdate, float Wage);
	NhanVien(string name, int workdate);
	NhanVien(const NhanVien &temp);
	~NhanVien();

	string getName() { return this->HoTen; }
	void setName(string newName) { this->HoTen = newName; }

	int getNgayLamViec() { return this->ngayLamViec; }
	void setNgayLamViec(int workdate);

	string getMaso() { return this->ID; }
	void setMaso(string maso) { this->ID = maso; }

	float getHeSoLuong() { return this->HeSoLuong; }
	void setHeSoLuong(float wage) { if (wage > 0) this->HeSoLuong = wage; }

	string getChucDanh() { return this->ChucDanh; }
	void setChucDanh(string position);
	
};
istream& operator>>(istream& in, NhanVien& temp);
ostream& operator<<(ostream& out, NhanVien& temp);
#endif // !NHAN_VIEN
