#include "NhanVien.h"
NhanVien::NhanVien()
{
	HoTen = "";
	ngayLamViec = 0;
	ID = "0";
	ChucDanh = "Nhan Vien";
	HeSoLuong = 1.0;
}
NhanVien::NhanVien(string name, string maSo, string Position, int workdate, float Wage)
{
	HoTen = name;
	ID = maSo;
	HeSoLuong = Wage;
	ngayLamViec = workdate;
	HeSoLuong = Wage;
}
NhanVien::NhanVien(string name, int workdate)
{
	HoTen = name;
	ngayLamViec = workdate;

	ID = to_string(ngayLamViec) + name;
	if (ngayLamViec > 0 && ngayLamViec < 365) ChucDanh = "Nhan Vien";
	else if (ngayLamViec >= 365 && ngayLamViec <= 730) ChucDanh = "Quan Ly";
	else if (ngayLamViec > 730 && ngayLamViec <= 1460) ChucDanh = "Truong phong";
	else if (ngayLamViec > 1460) ChucDanh = "Truong ban quan ly";
	if (ChucDanh == "Nhan Vien") HeSoLuong = 1.0;
	else if (ChucDanh == "Quan Ly") HeSoLuong = 1.5;
	else if (ChucDanh == "Truong phong") HeSoLuong = 2.25;
	else HeSoLuong = 4.0;
}
NhanVien::NhanVien(const NhanVien& temp)
{
	ChucDanh = temp.ChucDanh;
	HeSoLuong = temp.HeSoLuong;
	ngayLamViec = temp.ngayLamViec;
	HoTen = "";
	ID = to_string(ngayLamViec);
}
NhanVien::~NhanVien() { cout << "Da xoa nhan vien " << HoTen << endl; }
void NhanVien::setNgayLamViec(int workdate)
{
	if (workdate < 0)
	{
		cout << "invalid" << endl;
		return;
	}
	ngayLamViec = workdate;
}
void NhanVien::setChucDanh(string position)
{
	if (position == "Nhan Vien" || position == "Quan Ly" || position == "Truong phong" || position == "Truong ban quan ly")
	{
		ChucDanh = position;
		return;
	}
	cout << "Invalid" << endl;
}
istream& operator>>(istream& in, NhanVien& temp)
{
	int t;
	cout << "Bam 1 de nhap kieu 5 tham so\nBam 2 de nhap kieu 2 tham so: ";
	in >> t;
	if (t == 1)
	{
		string nah;
		cout << "Nhap ho va ten: ";
		getline(in, nah);
		temp.setName(nah);
		cout << "Nhap so ngay lam viec: ";
		in >> t;
		temp.setNgayLamViec(t);
		getline(in, nah);
		cout << "Nhap ma so: ";
		getline(in, nah);
		temp.setMaso(nah);
		cout << "Nhap chuc danh: ";
		getline(in, nah);
		temp.setChucDanh(nah);
		float heso = 0;
		in >> heso;
		in.ignore();
		temp.setHeSoLuong(heso);
	}
	else if (t == 2)
	{
		string nah;
		cout << "Nhap vao ho va ten: ";
		getline(in, nah);
		cout << "Nhap vao so ngay lam viec: ";
		cin >> t;
		temp = NhanVien(nah, t);
	}
	else temp = NhanVien();
	return in;
}
ostream& operator<<(ostream& out, NhanVien& temp)
{
	out << "Name: " << temp.getName() << endl;
	out << "So ngay lam viec: " << temp.getNgayLamViec() << endl;
	out << "Ma so nhan vien: " << temp.getMaso() << endl;
	out << "Chuc danh: " << temp.getChucDanh() << endl;
	out << "He so luong: " << temp.getHeSoLuong() << endl;
	return out;
}