#include <string>
#include <iostream>
#include <fstream>
using namespace std;
class HocSinh
{
	string name;
	string phone;
	float DTB;
public:
	HocSinh()
	{
		name = "";
		phone = "";
		DTB = 0;
	}
	bool isValid();
	friend istream& operator>>(istream& in, HocSinh& temp);
	friend ostream& operator<<(ostream& out, HocSinh temp);
};
bool HocSinh::isValid()
{
	if (DTB > 10 || DTB < 0)
		return false;
	if (name.size() > 20)
		return false;
	if(phone.size() > 11)
		return false;
	for (int i = 0; i < name.size(); i++)
	{
		if (name[i] >= 'a' && name[i] <= 'z' || name[i] >= 'A' && name[i] <= 'Z' || name[i] == ' ')
			continue;
		else
			return false;
	}
	for (int i = 0; i < phone.size(); i++)
	{
		if (phone[i] >= '0' && phone[i] <= '9')
			continue;
		else
			return false;
	}
	return true;
}

istream& operator>>(istream& in, HocSinh& temp)
{
	cout << "Nhap ho va ten: ";
	getline(in, temp.name);
	cout << "Nhap so dien thoai: ";
	getline(in, temp.phone);
	cout << "Nhap vao DTB: ";
	in >> temp.DTB;
	string ignoreSpace;
	getline(cin, ignoreSpace);
	while (!temp.isValid())
	{
		cout << "Khong hop le ! \n";
		cout << "Nhap ho va ten: ";
		getline(in, temp.name);
		cout << "Nhap so dien thoai: ";
		getline(in, temp.phone);
		cout << "Nhap vao DTB: ";
		cin >> temp.DTB;
		getline(cin, ignoreSpace);
	}
	return in;
}
ostream& operator<<(ostream& out, HocSinh temp)
{
	out << "Name: " << temp.name << endl;
	out << "SDT: " << temp.phone << endl;
	out << "DTB: " << temp.DTB << endl;
	return out;
}
int main()
{
	HocSinh temp;
	cin >> temp;
	cout << temp;
}