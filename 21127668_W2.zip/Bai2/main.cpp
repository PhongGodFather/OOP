#include "LopHoc.h"
int main()
{
	LopHoc temp;
	temp.readFile();
	cout << temp;
	cin >> temp;
	cout << temp;
	temp.XoaHocSinh("Vo Cao Tri");
	cout << temp;
	temp.sortDecrease();
	cout << temp;
}