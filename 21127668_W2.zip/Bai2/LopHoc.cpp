#include "LopHoc.h"
bool HocSinh::isValid()
{
	if (DTB > 10 || DTB < 0)
		return false;
	if (name.size() > 20)
		return false;
	if (phone.size() > 11)
		return false;
	for (int i = 0; i < name.size(); i++)
	{
		if (name[i] >= 'a' && name[i] <= 'z' || name[i] >= 'A' && name[i] <= 'Z' || name[i] == ' ')
			continue;
		else
			return false;
	}
	for (int i = 0; i < phone.size(); i++)
	{
		if (phone[i] >= '0' && phone[i] <= '9')
			continue;
		else
			return false;
	}
	return true;
}

istream& operator>>(istream& in, HocSinh& temp)
{
	cout << "Nhap ho va ten: ";
	getline(in, temp.name);
	cout << "Nhap so dien thoai: ";
	getline(in, temp.phone);
	cout << "Nhap vao DTB: ";
	in >> temp.DTB;
	string ignoreSpace;
	getline(cin, ignoreSpace);
	while (!temp.isValid())
	{
		cout << "Khong hop le ! \n";
		cout << "Nhap ho va ten: ";
		getline(in, temp.name);
		cout << "Nhap so dien thoai: ";
		getline(in, temp.phone);
		cout << "Nhap vao DTB: ";
		cin >> temp.DTB;
		getline(cin, ignoreSpace);
	}
	return in;
}
ostream& operator<<(ostream& out, HocSinh temp)
{
	out << "Name: " << temp.name << endl;
	out << "SDT: " << temp.phone << endl;
	out << "DTB: " << temp.DTB << endl;
	return out;
}
void LopHoc::readFile()
{
	fstream file("LopHoc.txt", ios::in);
	file >> numberStudent;
	string space = "";
	getline(file, space, '\n');
	for (int i = 0; i < numberStudent; i++)
	{
		HocSinh* temp = new HocSinh();
		getline(file, temp->name, '\n');
		getline(file, temp->phone, '\n');
		file >> temp->DTB;
		getline(file, space, '\n');
		studentList.push_back(temp);
	}
	file.close();
}
ostream& operator<<(ostream& out, LopHoc temp)
{
	out << "\nTong so hoc sinh: " << temp.numberStudent << endl;
	for (auto hocsinh: temp.studentList)
	{
		out << "Name: " << hocsinh->name << endl;
		out << "Phone: " << hocsinh->phone << endl;
		out << "DTB: " << hocsinh->DTB << endl;
	}
	return out;
}
bool sameString(string a, string b)
{
	for (int i = 0; i < a.size(); i++)
		if (a[i] != b[i])
			return false;
	return true;
}
bool LopHoc::isExist(string ten)
{
	for (auto i : studentList)
		if (sameString(i->name, ten))
			return true;
	return false;
}
istream& operator>>(istream& in, LopHoc& temp) 
{
	HocSinh *tmp = new HocSinh();
	in >> *tmp;
	while (temp.isExist(tmp->name))
	{
		cout << "Da co hoc sinh trong lop\n";
		in >> *tmp;
	}
	cout << "Succeed\n";
	temp.studentList.push_back(tmp);
	return in;
}
void LopHoc::XoaHocSinh(string ten)
{
	for (int i = 0; i < numberStudent; i++)
		if (sameString(studentList[i]->name, ten))
		{
			studentList.erase(studentList.begin() + i);
			cout << "Da xoa hoc sinh " << ten << endl;
			return;
		}
	cout << "Khong co hoc sinh trong lop\n";
}
void LopHoc::sortDecrease()
{
	for (int i = 0; i < numberStudent; i++)
		for (int j = i; j < numberStudent; j++)
			if (studentList[i]->DTB < studentList[j]->DTB)
				swap(studentList[i], studentList[j]);
}