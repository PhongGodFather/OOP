#pragma once
#ifndef _LOP_HOC
#define _LOP_HOC
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
using namespace std;
class LopHoc;
class HocSinh
{
	string name;
	string phone;
	float DTB;
	bool isValid();
public:
	HocSinh()
	{
		name = "";
		phone = "";
		DTB = 0;
	}
	friend istream& operator>>(istream& in, HocSinh& temp);
	friend ostream& operator<<(ostream& out, HocSinh temp);

	friend ostream& operator<<(ostream& out, LopHoc temp);
	friend istream& operator>>(istream& in, LopHoc& temp);
	friend class LopHoc;
};
class LopHoc
{
	int numberStudent;
	vector<HocSinh*> studentList;
	bool isExist(string ten);
public:
	LopHoc() { numberStudent = 0; }
	void readFile();
	void XoaHocSinh(string ten);
	void sortDecrease();
	friend ostream& operator<<(ostream& out, LopHoc temp);
	friend istream& operator>>(istream& out, LopHoc &temp);
};
ostream& operator<<(ostream& out, LopHoc temp);
istream& operator>>(istream& out, LopHoc& temp);
#endif // !_LOP_HOC
