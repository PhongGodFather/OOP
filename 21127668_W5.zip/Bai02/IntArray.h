#pragma once
#ifndef _INT_ARRAY_
#define _INT_ARRAY_
#include <iostream>
using namespace std;
class IntArray
{
	int* dulieu;
	int	kichthuoc;
public:
	IntArray();
	IntArray(int _kichthuoc);
	IntArray(const IntArray& temp);
	IntArray(int* a, int _kichthuoc);
	~IntArray();
	void setSize(int k);
	int size() { return kichthuoc; }
	void newArray(int size) { dulieu = new int[size]; }
	IntArray& operator=(const IntArray& temp);
	IntArray operator+(const IntArray& temp);
	IntArray operator++(int x);
	IntArray& operator++();
	friend istream& operator>>(istream& in, IntArray& temp);
	friend ostream& operator<<(ostream& out, IntArray temp);
};
istream& operator>>(istream& in, IntArray& temp);
ostream& operator<<(ostream& out, IntArray temp);
#endif // !
