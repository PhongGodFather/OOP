#include "IntArray.h"
IntArray::IntArray()
{
	kichthuoc = 0;
	dulieu = NULL;
}
IntArray::IntArray(int _kichthuoc)
{
	dulieu = new int[_kichthuoc];
	kichthuoc = _kichthuoc;
	for (int i = 0; i < kichthuoc; i++)
		dulieu[i] = 0;
}
IntArray::IntArray(const IntArray& temp)
{
	kichthuoc = temp.kichthuoc;
	dulieu = new int[kichthuoc];
	for (int i = 0; i < kichthuoc; i++)
		dulieu[i] = temp.dulieu[i];
}
IntArray::IntArray(int* a, int _kichthuoc) {
	kichthuoc = _kichthuoc;
	dulieu = new int[_kichthuoc];
	for (int i = 0; i < kichthuoc; i++, a++)
		dulieu[i] = *a;
}
IntArray::~IntArray()
{
	delete[]dulieu;
}
void IntArray::setSize(int k)
{
	if (k < 0)
	{
		cout << "Invalid" << endl;
		return;
	}
	if (k >= kichthuoc)
	{
		int* temp = new int[k];
		for (int i = 0; i < kichthuoc; i++)
			temp[i] = dulieu[i];
		const int oo = 1e8;
		dulieu = new int[k];
		for (int i = 0; i < kichthuoc; i++)
			dulieu[i] = temp[i];
		for (int i = kichthuoc; i < k; i++)
			dulieu[i] = oo;
		delete[] temp;
	}
	kichthuoc = k;
}
IntArray& IntArray::operator=(const IntArray& temp)
{
	setSize(temp.kichthuoc);
	dulieu = new int[kichthuoc];
	for (int i = 0; i < kichthuoc; i++)
		dulieu[i] = temp.dulieu[i];
	return *this;
}
IntArray IntArray::operator+(const IntArray& temp)
{
	int min_size = 0;
	int max_size = 0;
	if (temp.kichthuoc < kichthuoc)
	{
		min_size = temp.kichthuoc;
		max_size = kichthuoc;
	}
	else
	{
		max_size = temp.kichthuoc;
		min_size = kichthuoc;
	}
	IntArray result(max_size);
	for (int i = 0; i < min_size; i++)
		result.dulieu[i] = dulieu[i] + temp.dulieu[i];
	if (temp.kichthuoc == max_size)
	{
		for (int i = min_size; i < max_size; i++)
			result.dulieu[i] = temp.dulieu[i];
	}
	else
	{
		for (int i = min_size; i < max_size; i++)
			result.dulieu[i] = dulieu[i];
	}
	return result;
}
IntArray IntArray::operator++(int x)
{
	IntArray result(*this);
	for (int i = 0; i < kichthuoc; i++)
		dulieu[i] = dulieu[i] + 1;
	return result;
}
IntArray& IntArray::operator++()
{
	for (int i = 0; i < kichthuoc; i++)
		dulieu[i] = dulieu[i] + 1;
	return *this;
}
istream& operator>>(istream& in, IntArray& temp)
{
	int t;
	cout << "Nhap so luong phan tu: ";
	in >> t;
	while (t < 0)
	{
		cout << "Invalid: ";
		in >> t;
	}
	temp.setSize(t);
	temp.newArray(t);
	for (int i = 0; i < temp.size(); i++)
	{
		cout << "Phan tu thu " << i + 1 << " : ";
		in >> temp.dulieu[i];
	}
	return in;
}
ostream& operator<<(ostream& out, IntArray temp)
{
	for (int i = 0; i < temp.kichthuoc; i++)
		out << temp.dulieu[i] << " ";
	return out;
}