#include "IntArray.h"
void main()
{
	int a[] = { 1,2,3 };
	int m = 3;
	int b[] = { 4,5,6 ,7 };
	int n = 4;
	IntArray A(a, m);
	IntArray B(b, n);
	// A = B;
	cout << A << endl;
	cout << A + B << endl;
	cout << ++A << endl;
	cout << A++ << endl;
}