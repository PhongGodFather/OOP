#include "PhanSo.h"
PhanSo::PhanSo() 
{
	tuso = new int;
	mauso = new int;
	*tuso = 0;
	*mauso = 1;
}
PhanSo::PhanSo(int ts, int ms) {
	tuso = new int;
	mauso = new int;
	*tuso = ts;
	*mauso = ms;
}
PhanSo::PhanSo(int ts)
{
	tuso = new int;
	mauso = new int;
	*tuso = ts;
	*mauso = 1;
}
PhanSo::PhanSo(const PhanSo& temp)
{
	tuso = new int;
	mauso = new int;
	*tuso = *temp.tuso;
	*mauso = *temp.mauso;
}
PhanSo::~PhanSo()
{
	delete tuso;
	delete mauso;
}
void PhanSo::setMau(int ms)
{
	if (ms != 0)
		*mauso = ms;
}
int PhanSo::UCLN(int a, int b)
{
	if (b == 0)
		return a;
	return UCLN(b, a % b);
}
void PhanSo::rutGon()
{
	int UC = UCLN(abs(*tuso), abs(*mauso));
	*tuso = *tuso / UC;
	*mauso = *mauso / UC;
}
PhanSo PhanSo::operator+(const PhanSo& b) 
{
	PhanSo c;
	*c.tuso = *tuso * *b.mauso + *b.tuso * *mauso;
	*c.mauso = *mauso * *b.mauso;
	c.rutGon();
	return c;
}
PhanSo PhanSo::operator-(const PhanSo& b) 
{
	PhanSo c;
	*c.tuso = *tuso * *b.mauso - *b.tuso * *mauso;
	*c.mauso = *mauso * *b.mauso;
	c.rutGon();
	return c;
}
PhanSo PhanSo::operator*(const PhanSo& b) 
{
	PhanSo c;
	*c.tuso = *tuso * *b.tuso;
	*c.mauso = *mauso * *b.mauso;
	c.rutGon();
	return c;
}
PhanSo PhanSo::operator/(const PhanSo& b) 
{
	PhanSo c;
	*c.tuso = *tuso * *b.mauso;
	*c.mauso = *mauso * *b.tuso;
	c.rutGon();
	return c;
}
PhanSo& PhanSo::operator+=(const PhanSo& b) 
{
	*tuso = *tuso * *b.mauso + *b.tuso * *mauso;
	*mauso = *mauso * *b.mauso;
	rutGon();
	return *this;
}
PhanSo& PhanSo::operator-=(const PhanSo& b) {
	*tuso = *tuso * *b.mauso - *b.tuso * *mauso;
	*mauso = *mauso * *b.mauso;
	rutGon();
	return *this;
}
PhanSo& PhanSo::operator*=(const PhanSo& b) {
	*tuso = *tuso * *b.tuso;
	*mauso = *mauso * *b.mauso;
	rutGon();
	return *this;
}
PhanSo& PhanSo::operator/=(const PhanSo& b) {
	*tuso = *tuso * *b.mauso;
	*mauso = *mauso * *b.tuso;
	rutGon();
	return *this;
}
PhanSo& PhanSo::operator=(const PhanSo& ps)
{
	if (this == &ps)
		return *this;
	delete tuso;
	delete mauso;
	tuso = new int;
	mauso = new int;
	setTu(*ps.tuso);
	setMau(*ps.mauso);
	return *this;
}
PhanSo& PhanSo::operator++()
{
	*tuso = *tuso + *mauso;
	return *this;
}
PhanSo PhanSo::operator++(int x)
{
	return ++(* this);
}
bool PhanSo::operator==(const PhanSo& ps)
{
	int result = *tuso * *ps.mauso - *mauso * *ps.tuso;
	if (result == 0)
		return true;
	else
		return false;
}
bool PhanSo::operator!=(const PhanSo& ps)
{
	int result = *tuso * *ps.mauso - *mauso * *ps.tuso;
	if (result == 0)
		return false;
	else
		return true;
}
bool PhanSo::operator>(const PhanSo& ps)
{
	int result = *tuso * *ps.mauso - *mauso * *ps.tuso;
	if (result > 0)
		return true;
	else
		return false;
}
bool PhanSo::operator<(const PhanSo& ps)
{
	int result = *tuso * *ps.mauso - *mauso * *ps.tuso;
	if (result < 0)
		return true;
	else
		return false;
}
bool PhanSo::operator>=(const PhanSo& ps)
{
	int result = *tuso * *ps.mauso - *mauso * *ps.tuso;
	if (result >= 0)
		return true;
	else
		return false;
}
bool PhanSo::operator<=(const PhanSo& ps)
{
	int result = *tuso * *ps.mauso - *mauso * *ps.tuso;
	if (result <= 0)
		return true;
	else
		return false;
}
istream& operator>>(istream& in, PhanSo& temp)
{
	int k;
	cout << "Nhap tu so: ";
	in >> k;
	temp.setTu(k);
	cout << "Nhap mau so: ";
	in >> k;
	while (k == 0) 
	{
		cout << "Nhap lai mau so: ";
		in >> k;
	}
	temp.setMau(k);
	temp.rutGon();
	return in; 
}
ostream& operator<<(ostream& out, PhanSo temp)
{
	out << temp.getTu() << "/" << temp.getMau() << endl;
	return out;
}