#include "PhanSo.h"
#include <iostream>
using namespace std;
int main()
{
	cout << "Nhap phan so A:\n";
	PhanSo A;
	cin >> A;
	cout << A;

	// cout << A + PhanSo(1, 2) + PhanSo(5, 4) << endl;
	/*cout << A++ << endl;
	PhanSo nah = A;
	cout << nah;*/

	cout << "Nhap phan so B:\n";
	PhanSo B;
	cin >> B;
	cout << B;

	cout << "\nCong: ";
	cout << A + B;
	cout << "\nTru: ";
	cout << A - B;
	cout << "\nNhan: ";
	cout << A * B;
	cout << "\nChia: ";
	cout << A / B;

	cout << (A != B) << endl;
	cout << (A > B) << endl;
	cout << (A <= B) << endl;
	cout << (A >= B);
}