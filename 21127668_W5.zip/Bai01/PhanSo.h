#pragma once
#ifndef _PHAN_SO_
#define _PHAN_SO_
#include<iostream>
#include<cmath>
using namespace std;
class PhanSo
{
	int* tuso;
	int* mauso;
public:
	PhanSo();
	PhanSo(int ts, int ms);
	PhanSo(int ts);
	PhanSo(const PhanSo& temp);
	~PhanSo();
	int getTu() { return *tuso; }
	int getMau() { return *mauso; }
	void setTu(int ts) { *tuso = ts; }
	void setMau(int ms);
	int UCLN(int a, int b);
	void rutGon();
	PhanSo operator+(const PhanSo& b);
	PhanSo operator-(const PhanSo& b);
	PhanSo operator*(const PhanSo& b);
	PhanSo operator/(const PhanSo& b);
	PhanSo& operator+=(const PhanSo& b);
	PhanSo& operator-=(const PhanSo& b);
	PhanSo& operator*=(const PhanSo& b);
	PhanSo& operator/=(const PhanSo& b);
	PhanSo& operator=(const PhanSo& ps);
	PhanSo operator++(int x);
	PhanSo& operator++();
	bool operator==(const PhanSo& ps);
	bool operator!=(const PhanSo& ps);
	bool operator>(const PhanSo& ps);
	bool operator<(const PhanSo& ps);
	bool operator>=(const PhanSo& ps);
	bool operator<=(const PhanSo& ps);
};
istream& operator>>(istream& in, PhanSo& temp);
ostream& operator<<(ostream& out, PhanSo temp);
#endif // !_PHAN_SO_
