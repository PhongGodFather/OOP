#include<iostream>
#include "PhanSo.h"
using namespace std;
int main()
{
    cout << "Nhap phan so A:\n";
    PhanSo A;
    cin >> A;
    cout << A; // type 1
    cout < A; // type 2

    /*A.setTu(2);
    A.setMau(3);
    cout << A.getTu() << endl;
    cout << A.getMau() << endl;*/

     cout << "Nhap phan so B:\n";
     PhanSo B;
     cin >> B;
     cout << B;
     cout < B;

     cout << "\nCong: ";
     cout << A + B;
     cout < A + B;

     cout << "\nTru: ";
     cout << A - B;
     cout < A - B;

     cout << "\nNhan: ";
     cout << A * B;
     cout < A * B;

     cout << "\nChia: ";
     cout << A / B;
     cout < A / B;
}