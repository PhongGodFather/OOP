#include "PhanSo.h"
PhanSo::PhanSo() 
{
	tuso = new int;
	mauso = new int;
	*tuso = 0;
	*mauso = 1;
}
PhanSo::PhanSo(int ts, int ms) 
{
	tuso = new int;
	mauso = new int;
	*tuso = ts;
	*mauso = ms;
	rutGon();
}
PhanSo::PhanSo(int ts)
{
	tuso = new int;
	mauso = new int;
	*tuso = ts;
	*mauso = 1;
}
PhanSo::PhanSo(const PhanSo& temp)
{
	tuso = new int;
	mauso = new int;
	*tuso = *temp.tuso;
	*mauso = *temp.mauso;
	rutGon();
}
PhanSo::~PhanSo()
{
	delete tuso;
	delete mauso;
}
istream& operator>>(istream& in, PhanSo &temp)
{
	int t;
	cout << "Nhap tu so: ";
	in >> t;
	temp.setTu(t);
	cout << "Nhap mau so: ";
	in >> t;
	temp.setMau(t);
	while (temp.getMau() == 0) 
	{
		cout << "Nhap lai mau so: ";
		in >> t;
		temp.setMau(t);
	}
	temp.rutGon();
	return in;
}
ostream& operator<<(ostream& out, PhanSo temp)
{
	temp.rutGon();
	out << temp.getTu() << "/" << temp.getMau() << endl;
	return out;
}
ostream& operator<(ostream& out, PhanSo temp)
{
	out << (float)temp.getTu() / temp.getMau() << endl;
	return out;
}
int UCLN(int a, int b) 
{
	if (b == 0)
		return a;
	return UCLN(b, a % b);
}
void PhanSo::rutGon() 
{
	int UC = UCLN(abs(*tuso), abs(*mauso));
	*tuso = *tuso / UC;
	*mauso = *mauso / UC;
}
PhanSo PhanSo::operator+(PhanSo b) {
	PhanSo c;
	c.setTu(getTu() * b.getMau() + b.getTu() * getMau());
	c.setMau(getMau() * b.getMau());
	c.rutGon();
	return c;
}
PhanSo PhanSo::operator-(PhanSo b) {
	PhanSo c;
	c.setTu(getTu() * b.getMau() - b.getTu() * getMau());
	c.setMau(getMau() * b.getMau());
	c.rutGon();
	return c;
}
PhanSo PhanSo::operator*(PhanSo b) {
	PhanSo c;
	c.setTu(getTu() * b.getTu());
	c.setMau(getMau() * b.getMau());
	c.rutGon();
	return c;
}
PhanSo PhanSo::operator/(PhanSo b) {
	PhanSo c;
	c.setTu(getTu() * b.getMau());
	c.setMau(getMau() * b.getTu());
	c.rutGon();
	return c;
}