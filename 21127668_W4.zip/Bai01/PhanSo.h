#pragma once
#ifndef _PhanSo_
#define _PhanSo_
#include <iostream>
#include <math.h>
using namespace std;
class PhanSo
{
    int* tuso;
    int* mauso;
public:
    PhanSo();
    PhanSo(int ts, int ms);
    PhanSo(int ts);
    PhanSo(const PhanSo& temp);
    ~PhanSo();
    int getTu() { return *tuso; }
    int getMau() { return *mauso; }
    void setTu(int ts) { *tuso = ts; }
    void setMau(int ms)
    {
        if (ms != 0)
            *mauso = ms;
    }
    void rutGon();
    PhanSo operator+(PhanSo b);
    PhanSo operator-(PhanSo b);
    PhanSo operator*(PhanSo b);
    PhanSo operator/(PhanSo b);
};
istream& operator>>(istream& in, PhanSo& temp);
ostream& operator<<(ostream& out, PhanSo temp);
ostream& operator<(ostream & out, PhanSo temp);
#endif // !PhanSo
