#include "Hero.h"
Skill::Skill()
{
	skillName = "none";
	skillLevel = 0;
}
Skill::Skill(string sn)
{
	skillName = "none";
	skillName = sn;
}
Skill::Skill(unsigned int sl)
{
	skillLevel = sl;
	skillLevel = 0;
}
Skill::Skill(string sn, unsigned int sl)
{
	skillLevel = sl;
	skillName = sn;
}
Skill::Skill(const Skill& temp)
{
	skillLevel = temp.skillLevel;
	skillName = temp.skillName;
}
string Skill::getSkillName()
{
	return skillName;
}
unsigned int Skill::getSkillLevel()
{
	return skillLevel;
}
void Skill::setSkillName(string sn)
{
	skillName = sn;
}
void Skill::setSkillLevel(unsigned int sl)
{
	skillLevel = sl;
}
istream& operator>>(istream& in, Skill &tmp)
{
	string sn;
	unsigned int sl;
	cout << "SkillName: ";
	getline(in, sn);
	tmp.setSkillName(sn);
	cout << "LevelSkill: ";
	in >> sl;
	tmp.setSkillLevel(sl);
	getline(in, sn); // avoid enter blank
	return in;
}
ostream& operator<<(ostream& out, Skill &tmp)
{
	out <<"Skill name: " << tmp.getSkillName() << endl;
	out <<"Skill level: " << tmp.getSkillLevel() << endl;
	return out;
}
Hero::Hero()
{
	heroName = "none";
	heroHealth = 0;
	heroMana = 0;
	heroLevel = 0;
}
Hero::Hero(string heroname)
{
	heroName = heroname;
	heroHealth = 0;
	heroMana = 0;
	heroLevel = 0;
}
Hero::Hero(unsigned int heroThing, int mode)
{
	heroName = "none";
	if (mode == 1) // set health
	{
		heroHealth = heroThing;
		heroMana = 0;
		heroLevel = 0;
	}
	else if (mode == 2) // set mana
	{
		heroHealth = 0;
		heroMana = heroThing;
		heroLevel = 0;
	}
	else // set level
	{
		heroHealth = 0;
		heroMana = 0;
		heroLevel = heroThing;
	}
}
Hero::Hero(Skill &temp)
{
	heroName = "none";
	heroHealth = 0;
	heroMana = 0;
	heroLevel = 0;
	skillList.push_back(&temp);
}
Hero::Hero(string heroname, unsigned int heroThing, int mode)
{
	heroName = heroname;
	if (mode == 1)
	{
		heroHealth = heroThing;
		heroMana = 0;
		heroLevel = 0;
	}
	else if (mode == 2)
	{
		heroHealth = 0;
		heroMana = heroThing;
		heroLevel = 0;
	}
	else
	{
		heroHealth = 0;
		heroMana = 0;
		heroLevel = heroThing;
	}
}
Hero::Hero(string heroname, Skill temp)
{
	heroName = heroname;
	heroHealth = 0;
	heroMana = 0;
	heroLevel = 0;
	skillList.push_back(&temp);
}
Hero::Hero(unsigned int heroThing1, unsigned int heroThing2, int mode)
{
	heroName = "none";
	if (mode == 1)
	{
		heroHealth = heroThing1;
		heroMana = heroThing2;
		heroLevel = 0;
	}
	else if (mode == 2)
	{
		heroHealth = heroThing1;
		heroMana = 0;
		heroLevel = heroThing2;
	}
	else
	{
		heroHealth = 0;
		heroMana = heroThing1;
		heroLevel = heroThing2;
	}
}
Hero::Hero(Skill temp, unsigned int heroThing, int mode)
{
	heroName = "none";
	skillList.push_back(&temp);
	if (mode == 1)
	{
		heroHealth = heroThing;
		heroMana = 0;
		heroLevel = 0;
	}
	else if (mode == 2)
	{
		heroHealth = 0;
		heroMana = heroThing;
		heroLevel = 0;
	}
	else
	{
		heroHealth = 0;
		heroMana = 0;
		heroLevel = heroThing;
	}
}
Hero::Hero(const Hero& hero)
{
	heroName = hero.heroName;
	heroHealth = hero.heroHealth;
	heroMana = hero.heroMana;
	heroLevel = hero.heroLevel;
	setAllSkill(hero.skillList);
}
string Hero::getHeroName()
{
	return heroName;
}
unsigned int Hero::getHeroHealth()
{
	return heroHealth;
}
unsigned int Hero::getHeroMana()
{
	return  heroMana;
}
unsigned int Hero::getHeroLevel()
{
	return  heroLevel;
}
vector<Skill*> Hero::getSkillList()
{
	return skillList;
}
void Hero::setHeroName(string heroname)
{
	heroName = heroname;
}
void Hero::setHeroHealth(unsigned int herohealth)
{
	heroHealth = herohealth;
}
void Hero::setHeroMana(unsigned int heromana)
{
	heroMana = heromana;
}
void Hero::setHeroLevel(unsigned int herolevel)
{
	heroLevel = herolevel;
}
void Hero::setAllSkill(const vector<Skill*> temp)
{
	skillList = vector<Skill*>(temp.begin(), temp.end());
}
istream& operator>>(istream& in, Hero &tmp)
{
	string nah;
	unsigned int temp;
	cout << "Enter Hero name: ";
	getline(in, nah);
	tmp.setHeroName(nah);
	cout << "Enter Hero health: ";
	in >> temp;
	tmp.setHeroHealth(temp);
	cout << "Enter Hero mana: ";
	in >> temp;
	tmp.setHeroMana(temp);
	cout << "Enter Hero level: ";
	in >> temp;
	tmp.setHeroLevel(temp);

	cout << "Size of Skill list: ";
	in >> temp;
	getline(in, nah);
	while (temp)
	{
		temp--;
		Skill *ok = new Skill();
		in >> *ok;
		tmp.addSkill(ok);
	}
	return in;
}
ostream& operator<<(ostream& out, Hero &temp)
{
	out << "Hero Name: " << temp.getHeroName() << endl;
	out << "Hero Health: " << temp.getHeroMana() << endl;
	out << "Hero Mana: " << temp.getHeroMana() << endl;
	out << "Hero Level: " << temp.getHeroLevel() << endl;
	int k = 1;
	for (auto i : temp.getSkillList())
	{
		out << "Skill " << k++ << " -> " << endl;
		out << *i;
	}
	return out;
}
void Hero::possibleSkill()
{
	cout << "Skills: " << endl;
	for (auto i : skillList)
		if (i->getSkillLevel() <= heroLevel)
			cout << i->getSkillName() << ":" << i->getSkillLevel() << endl;
}
void Hero::deleteSkill()
{
	int n;
	cout << "Nhap so luong skill can xoa: ";
	cin >> n;
	if (n >= skillList.size())
	{
		skillList.clear();
		return;
	}
	while (n)
	{
		n--;
		skillList.pop_back();
	}
}