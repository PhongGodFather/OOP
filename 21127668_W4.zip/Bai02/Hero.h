#pragma once
#ifndef _HERO_
#define _HERO_
#include<iostream>
#include<cmath>
#include<vector>
#include<string>
using namespace std;
class Skill
{
	string skillName;
	unsigned int skillLevel;
public:
	Skill();
	Skill(string sn);
	Skill(unsigned int sl);
	Skill(string sn, unsigned int sl);
	Skill(const Skill& temp);
	string getSkillName();
	unsigned int getSkillLevel();
	void setSkillName(string sn);
	void setSkillLevel(unsigned int sl);
	~Skill() {}
};
istream& operator>>(istream& in, Skill& tmp);
ostream& operator<<(ostream& out, Skill& tmp);
class Hero
{
	string heroName;
	unsigned int heroHealth;
	unsigned int heroMana;
	unsigned int heroLevel;
	vector<Skill*> skillList;
public:
	Hero();
	Hero(string heroname);
	Hero(unsigned int heroThing, int mode = 1);
	Hero(Skill& temp);
	Hero(string heroname, unsigned int heroThing, int mode = 1);
	Hero(string heroname, Skill temp);
	Hero(unsigned int heroThing1, unsigned int heroThing2, int mode = 1);
	Hero(Skill temp, unsigned int heroThing, int mode = 1);
	Hero(const Hero& hero);

	string getHeroName();
	unsigned int getHeroHealth();
	unsigned int getHeroMana();
	unsigned int getHeroLevel();
	void addSkill(Skill *tmp) { skillList.push_back(tmp); }
	vector<Skill*> getSkillList();
	void setHeroName(string heroname);
	void setHeroHealth(unsigned int herohealth);
	void setHeroMana(unsigned int heromana);
	void setHeroLevel(unsigned int herolevel);
	void setAllSkill(const vector<Skill*> temp);
	void possibleSkill();
	void deleteSkill();
	~Hero() { }
};
istream& operator>>(istream& in, Hero& temp);
ostream& operator<<(ostream& out, Hero& temp);
#endif // !_HERO_