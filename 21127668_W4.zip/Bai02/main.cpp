#include "Hero.h"
int main()
{
	Skill a("Blazing", 100);
	/*cin >> a;
	cout << a;*/

	//Skill b(a);
	//cout << b;
	//cin >> a;
	//cout << a;
	Hero A(a);
	// cin >> A;
	cout << A;
	cout << "List of possible skills that can be achieved: \n";
	A.possibleSkill();

	A.deleteSkill();
	cout << A;
}