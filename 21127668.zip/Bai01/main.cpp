#include <iostream>
using namespace std;
class PhanSo {
public:
	int tu, mau;
	void input()
	{
		cout << "Nhap vao tu: ";
		cin >> tu;
		cout << "Nhap vao mau: ";
		cin >> mau;
		while (mau == 0)
		{
			cout << "Nhap lai mau: ";
			cin >> mau;
		}
	}
	void ToiGian()
	{
		int min = (tu < mau) ? tu : mau;
		while (true)
		{
			if (tu % min == 0 && mau % min == 0)
				break;
			min--;
		}
		tu /= min;
		mau /= min;
	}
	void Out1() 
	{
		if (mau == 1)
			cout <<"Style 1: " << tu << endl;
		else
			cout <<"Style 1: " << tu << "/" << mau << endl;
	}
	void Out2(){
		float a = (float)tu / (float)mau;
		cout <<"Style 2: " << a << endl;
	}
	PhanSo Cong(PhanSo b)
	{
		PhanSo temp;
		temp.tu = tu * b.mau + mau * b.tu;
		temp.mau = mau * b.mau;
		temp.ToiGian();
		return temp;
	}
	PhanSo Tru(PhanSo b)
	{
		PhanSo temp;
		temp.tu = tu * b.mau - mau * b.tu;
		temp.mau = mau * b.mau;
		temp.ToiGian();
		return temp;
	}
	PhanSo Nhan(PhanSo b)
	{
		PhanSo temp;
		temp.tu = tu * b.tu;
		temp.mau = mau * b.mau;
		temp.ToiGian();
		return temp;
	}
	PhanSo Chia(PhanSo b)
	{
		PhanSo temp;
		temp.tu = tu * b.mau;
		temp.mau = mau * b.tu;
		temp.ToiGian();
		return temp;
	}
};
int main()
{
	PhanSo a;
	a.input();
	a.ToiGian();
	a.Out1();
	a.Out2();

	PhanSo b;
	b.input();
	b.Out1();
	b.Out2();

	cout << "Tong 2 phan so tren: \n";
	a.Cong(b).Out1();
	a.Cong(b).Out2();

	cout << "Hieu 2 phan so tren: \n";
	a.Tru(b).Out1();
	a.Tru(b).Out2();

	cout << "Tich 2 phan so tren: \n";
	a.Nhan(b).Out1();
	a.Nhan(b).Out2();

	cout << "Thuong 2 phan so tren: \n";
	a.Chia(b).Out1();
	a.Chia(b).Out2();
}