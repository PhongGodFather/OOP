#include <iostream>
#include <cmath>
using namespace std;
class Point
{
private:
	float x, y;
public:
	void Nhap()
	{
		cout << "Nhap x: ";
		cin >> x;
		cout << "Nhap y: ";
		cin >> y;
	}
	double distance(Point b)
	{
		return sqrt((b.x - x) * (b.x - x) + (b.y - y) * (b.y - y));
	}
	void out() { cout << "(" << x << "," << y << ")\n";}
};
int main()
{
	Point a;
	Point b;
	a.Nhap();
	a.out();
	b.Nhap();
	b.out();
	cout << "Khoang cach giua diem A va diem B: " << a.distance(b) << endl;
}