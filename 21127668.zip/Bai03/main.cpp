#include <iostream>
#include <cmath>
using namespace std;
class Point
{
private:
	float x, y;
public:
	void input()
	{
		cout << "Nhap x: ";
		cin >> x;
		cout << "Nhap y: ";
		cin >> y;
	}
	double distance(Point b) { return sqrt((b.x - x) * (b.x - x) + (b.y - y) * (b.y - y)); }
	void out() { cout << "(" << x << "," << y << ")\n"; }
};
class Rectangle
{
private:
	Point a, b, c, d;
	bool isValid()
	{
		if (b.distance(d) != a.distance(c))
			return false;
		float k = sqrt(pow(a.distance(b), 2) + pow(a.distance(d), 2));
		float py = b.distance(d);
		if (k != py)
			return false;
		return true;
	}
public:
	void input()
	{
		cout << "Nhap vao dinh thu 1: \n";
		a.input();
		cout << "Nhap vao dinh thu 2: \n";
		b.input();
		cout << "Nhap vao dinh thu 3: \n";
		c.input();
		cout << "Nhap vao dinh thu 4: \n";
		d.input();
	}
	void out()
	{
		cout << "Diem thu 1: ";
		a.out();
		cout << "Diem thu 2: ";
		b.out();
		cout << "Diem thu 3: ";
		c.out();
		cout << "Diem thu 4: ";
		d.out();
		if (isValid())
			cout << "\nHinh chu nhat hop le\n";
		else
			cout << "\nHinh chu nhat khong hop le\n";
	}
	float Area() { 
		if (isValid())
			return a.distance(b) * a.distance(d);
		cout << "\nKhong hop le\n";
		return -1;
	}
	float Perimeter() { 
		if (isValid())
			return 2 * (a.distance(b) + a.distance(d)); 
		cout << "\nKhong hop le\n";
		return -1;
	}
};
void main()
{
	Rectangle a;
	a.input();
	a.out();
	cout <<"Dien tich la: " << a.Area() << endl;
	cout <<"Chu vi la: " << a.Perimeter() << endl;
}